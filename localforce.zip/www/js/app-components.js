/*
	All app components 
*/
var app = {
    models: {},
    views: {},
    utils: {}
};

var allRecords = [];


// Init Ext js App 
var appjs = Ext.application({
	name : 'BuilderEdge',
	launch : function() {
		
		console.log('### loadData');
		loadData();
		
	}
});

// Show Loader Animation
function showLoader(){
	$('.loader, .backdrop').show();
}

// Hide Loader Animation
function hideLoader(){
	$('.loader, .backdrop').hide();
}


// Init app panel frames 
var panel;
var attachPanel;
function getTabs(){
	Ext.Viewport.add({
		xtype: 'tabpanel',
		items: [{
			title: 'Accounts',
			xtype: 'grid',
			iconCls: 'x-fa fa-users',
			id:"my-table",
			listeners: {
				itemtap: function(view, index, item, record) {
					Ext.Viewport.add({
						xtype: 'formpanel',
						title: 'Update Account',
						width: 400,
						floating: true,
						centered: true,
						modal: true,

						record: record,
						viewModel : {
							data: {
								employee: record
							}
						},
						items: [{
							xtype: 'textfield',
							name: 'Name',
							label: 'Name',
							bind: '{employee.Name}'
						},
						{
							xtype: 'textfield',
							name: 'Industry',
							label: 'Industry',
							bind: '{employee.Industry}'
						}
						,{
							xtype: 'toolbar',
							docked: 'bottom',
							items: ['->', {
								xtype: 'button',
								text: 'Save',
								iconCls: 'x-fa fa-check',
								handler: function() {
									console.log(record.data);
									panel = this.up('formpanel');
									Ext.Msg.confirm("Confirmation", "Are you sure you want to update account?", function(action){
										if(action=='yes'){
											updateRecord(record.data);
											panel.destroy();
										}
									});

								}
							}, {
								xtype: 'button',
								text: 'Delete',
								/*iconCls: 'x-fa fa-trash',*/
								handler: function() {
									panel = this.up('formpanel');
									Ext.Msg.confirm("Confirmation", "Are you sure you want to delete account?", function(action){
										if(action=='yes'){
											deleteAccount(record.data.Id);
											panel.destroy();
										}
									});

								}
							},{
								xtype: 'button',
								text: 'File',
								iconCls: 'x-fa fa-plus',
								handler: function() {
									//this.up('formpanel').destroy();
									panel = this.up('formpanel');

									// Start of Attachment popup //
									Ext.Viewport.add({
										xtype: 'formpanel',
										title: 'Upload File',
										width: 400,
										floating: true,
										centered: true,
										modal: true,
										items: [{ //MULTIFILEFIELD
											xtype: 'filefield',
											label: "MyPhoto:",
											name: 'photo',
											accept: '/*',
											id:"inputfile"
										},{

											xtype: 'toolbar',
											docked: 'bottom',
											items: ['->', {
												xtype: 'button',
												text: 'Upload',
												iconCls: 'x-fa fa-check',
												handler: function() {
													attachPanel = this.up('formpanel');

													if( $('#inputfile [type=file]')[0].files.length > 0 ){

														/*if( (!navigator.onLine) && ($('#inputfile [type=file]')[0].files[0].size / 1024) > 1000){
															 Ext.Msg.alert('Error', 'Maximum 1MB file can be selected in offline mode!');
															 return false;
														}*/

														var input = $('#inputfile [type=file]')[0];

														file = input.files[0]; // The file
														console.log('Name >>> '+file.name);
														console.log('Size >>> '+file.size);
														console.log('Type >>> '+file.type);

														//var fileLocation = URL.createObjectURL(file);
														var attachment = {
															Id: null,
															ParentId: record.data.Id,
															Name: file.name,
															ContentType: file.type,
															Body: ''
														};

														fr = new FileReader();
														fr.onload = function () {

															//console.log( fr.result );

															var data = fr.result.split(',')[1];
															attachment['Body'] = data;

															addAttachment(attachment);

															panel.destroy();
															attachPanel.destroy();

														};
														//fr.readAsText( file );
														fr.readAsDataURL( file );

													}else{
														Ext.Msg.alert('Warning', 'No file selected!');
													}

												}
											},
											{
												xtype: 'button',
												text: 'Close',
												iconCls: '',
												handler: function() {
													this.up('formpanel').destroy();
												}
											}]

										}]
									});
									// End of Attachment popup //
								}
							},{
									xtype: 'button',
									text: 'Close',
									/*iconCls: 'x-fa fa-close',*/
									handler: function() {
										this.up('formpanel').destroy();
									}
							}]
						}]
					});
				}
			},
			store: {
				data: allRecords
			},
			columns: [{
				text: 'Name',
				dataIndex: 'Name',
				flex: 1
			},
			{
				text: 'Industry',
				dataIndex: 'Industry',
				flex: 1
			}]
		},

		{
			title: 'Add New',
			iconCls: 'x-fa fa-plus',
			id : "my-div"
		}
		
		]
	});

	initForm();
}

// Init form for create new record
var form;
function initForm(){
	  form = Ext.create('Ext.form.Panel', {
	  renderTo: Ext.get("my-div"),
	  title:"New Account",
	  id: 'account-form',
	  height: 600,
	  items: [
		  {
			  xtype: 'textfield',
			  label: 'Name',
			  fieldLabel: 'Name',
			  name: 'Name'
		  },
		  {
			  xtype: 'textfield',
			  label: 'Industry',
			  fieldLabel: 'Industry',
			  name: 'Industry'
		  }/*,  // Back up code for submit form button 
		  {   
			  xtype: 'button',
			  text: 'Submit',
			  handler: function() {
				  console.log(form.getValues());
				  addAccount(form.getValues());
			  }
		  }*/
	  ],

	  buttons: [
		{
		  text: 'Submit',
		  handler: function() {
			 console.log(form.getValues());
			 addAccount(form.getValues());
		  }
		}
	  ]

	});
}
