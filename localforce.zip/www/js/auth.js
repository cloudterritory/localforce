// Creating the application namespace
var app = {
    models: {},
    views: {},
    utils: {}
};

jQuery(document).ready(function() {

    //Add event listeners and so forth here
    console.log("onLoad: jquery ready");

    force.login(
        function() {
            console.log("Auth succeeded");

            Force.init();
            startApp();

        },
        function(error) {
            console.log("Auth failed: " + error);
        }
    );

});