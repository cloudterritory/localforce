
// Get auth info from cookie
function getCookie(cname) {
	var name = cname + "=";
	var decodedCookie = decodeURIComponent(document.cookie);
	var ca = decodedCookie.split(';');
	for(var i = 0; i <ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0) == ' ') {
			c = c.substring(1);
		}
		if (c.indexOf(name) == 0) {
			return c.substring(name.length, c.length);
		}
	}
	return "";
}

// Login callback function
function loginDialogCallback(hash, response) {
	console.log('Auth Success');
    if (response && response.access_token) {
		
		document.cookie = 'sftoken='+hash;
		
		window.location.href="main.html";
		
    } else {
        alert("AuthenticationError: No Token");
    }
	console.log(' exit --- Auth Success');
}

// Login 
function login(){
	
	var params = {
		appId : '3MVG9ZL0ppGP5UrBP2gjWWAUfP2ON7oN4jK8XTP94NskzRB9VjY7VsCZ582AUZdTc9c4_vWMgB3Br02gHf5WH',
		apiVersion : 'v39.0',
		loginURL : $('#type').val(),
	};	

	force.init(params);
	
	force.login();
}

// Init Session on other pages after login success
function initSession(){
	if( getCookie('sftoken') != '' ){
	
		var oauthResponse = {};
		if (getCookie('sftoken')) {
			var message = getCookie('sftoken').substr(1);
			var nvps = message.split('&');
			for (var nvp in nvps) {
				var parts = nvps[nvp].split('=');
				oauthResponse[parts[0]] = unescape(parts[1]);
			}
		}
		console.log(oauthResponse);
			
		var params = {
			accessToken : oauthResponse.access_token,
			instanceURL : oauthResponse.instance_url,
			refreshToken : oauthResponse.refresh_token,
			userId : oauthResponse.id
		};	

		force.init(params);
		
		//force.oauthCallback(getCookie('sftoken'));
		
	}else{
		window.location.href="index.html";
	}
}
// end check session


// Load Records from Object 
function loadData(){
   
	getRecords(
		'Select id, name, industry from account',
		function (data) {
			//console.log(data);
			
			console.log("Fetching Records!");

			var temp = data.records;
			for(var index=0; index<temp.length;index++){
				allRecords.push(temp[index]);
			}
			
			getTabs();
			
			hideLoader();
			//Ext.Msg.alert('Accounts', 'Loaded!');
		},
		function (error) {
			hideLoader();
			//Ext.Msg.alert("Error: " + JSON.stringify(error));
			
			Ext.Msg.alert(
				'Error', 
				JSON.stringify(error), 
				function(action){ 
					if(action == 'ok') 
						window.location.href='index.html#login';
				}
			);
			
			console.log("Failed to get record");
		}
	);
	
}

// Create Account
function addAccount(record){
	showLoader();
	
	var fields = {
		"Industry": record.Industry,
		"Name": record.Name,
	};
	
	console.log('fields : ',fields);
	
	createRecord(
		'Account',
		fields,
		function (data) {
			hideLoader();
			Ext.Msg.alert(
				'Success', 
				'New account has been created!', 
				function(action){ 
					if(action == 'ok') 
						window.location.reload(); 
				}
			);
		},
		function (error) {
			hideLoader();
			Ext.Msg.alert("Error: " + JSON.stringify(error));
			console.log("Failed to Create!");
		}
	);
	
}

// Update record
function updateRecord(record){
	showLoader();

	var fields = {
		Id: record.Id,
		Industry: record.Industry,
		Name: record.Name,
	};
	console.log('fields : ',fields);
	
	updateRow(
		'Account',
		fields,
		function (data) {
			hideLoader();
			Ext.Msg.alert('Accounts', 'Updated!'); 
		},
		function (error) {
			hideLoader();
			Ext.Msg.alert("Error: " + JSON.stringify(error));
			console.log("Failed to Update!");
		}
	);
	
}

// Delete Account
function deleteAccount(recordid){
	showLoader();
	
	force.del(
		'Account',
		recordid,
		function (data) {
			window.location.reload();
		},
		function (error) {
			hideLoader();
			Ext.Msg.alert("Error: " + JSON.stringify(error));
			console.log("Failed to delete record!");
		}
	);

}

// Create Attachment / Content Document 
function addAttachment(record){

	showLoader();

	var fields = {
		Id: null,
		Title: (record.Name.split('.')[0]),
		PathOnClient: record.Name,
		Origin: "C",
		VersionData: record.Body
	};

	console.log('final > ',fields);

	createRecord(
		'ContentVersion',
		fields,
		function (data) {
			
			createContentLink( data, record.ParentId );
			
		},
		function (error) {
			hideLoader();
			Ext.Msg.alert("Attachment Error: " + JSON.stringify(error));
			console.log("Failed to Create Attachment!");		
		}
	);
	
}

function createContentLink(cv, relatedToId){
	console.log('## Create Link >> '+cv['id']+' == '+relatedToId);
	console.log(cv);

	getRecord(
		'ContentVersion',
		cv['id'],
		'Id, ContentDocumentId',
		function (data) {
			console.log(data);
			
			var fields = {
				"ContentDocumentId": data['ContentDocumentId'],
				"LinkedEntityId": relatedToId,
				"ShareType":"V"
			};
			
			createRecord(
				'ContentDocumentLink',
				fields,
				function(succ){
					console.log(succ);
					
					hideLoader();
					
					Ext.Msg.alert(
						'Success',
						'New attachment has been created!',
						function(action){

						}
					);
				},
				function(err){
					console.log(err);
				}
			);
			
		},
		function (error) {              
			console.log("Failed to delete record!", error);
		}
	);
	
}	