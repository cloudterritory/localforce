function getRecords(Query, Success, Error){
	force.query(
		Query,
		function (data) {
			Success(data);
		},
		function (error) {
			Error(error);
		}
	);
}

function getRecord(ObjectName, Id, Fields, Success, Error){
	force.retrieve(
		ObjectName,
		Id,
		Fields,
		function (data) {
			Success(data);
		},
		function (error) {
			Error(error);
		}
	);	
}

function createRecord(ObjectName, Data, Success, Error){
	force.create(
		ObjectName,
		Data,
		function (data) {
			Success(data);
		},
		function (error) {
			Error(error);
		}
	);	
}

function updateRow(ObjectName, Data, Success, Error){
	force.update(
		ObjectName,
		Data,
		function (data) {
			Success(data);
		},
		function (error) {
			Error(error);
		}
	);	
}

function deleteRecord(ObjectName, Id, Success, Error){
	force.del(
		ObjectName,
		Id,		
		function (data) {
			Success(data);
		},
		function (error) {
			Error(error);
		}
	);	
}
